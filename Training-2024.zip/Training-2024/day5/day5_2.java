public class day5_2 {
    public static void main(String[] args) {
        int arr[]={0,5,3,6,7,2,1};
        int n=arr.length;

    }
}
