
import java.util.*;
public class missing_number {
    public static void main(String[] args) {
        int arr[]={0,5,3,7,4,2,1};
        int n=arr.length;
     int hash[]=new int[n+1];
     for(int i=0;i<n;i++){
         hash[arr[i]]++;
     }
//        for(int i=0;i<n;i++){
//            System.out.println(hash[arr[i]]);
//        }
        int missing=-1;

        for(int i=0;i<=n;i++){
             if(hash[i]==0){
                missing =i;
            }
        }
        System.out.println("repeating and missing :"+missing);

//        Arrays.sort(arr);
//        for(int i=0;i<n-1;i++){
//            if(arr[i]==arr[i+1]){
//                System.out.println(arr[i]);
//                break;
//            }
//        }
//        for(int i=0;i<n-1;i++){
//            if(arr[i+1]-arr[i]==2){
//                System.out.println(arr[i]+1);
//                break;
//            }
//        }

    }
}
