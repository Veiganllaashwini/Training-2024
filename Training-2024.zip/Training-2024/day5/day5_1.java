//import java.util.*;
//public class day5_1 {
//    public static void main(String[] args) {
//        int arr[]={1,2,3,1,1,1};
//        int n=arr.length/2;
////        int hash[]=new int[9];
////        Arrays.fill(hash,0);
////        for(int i=0;i<arr.length;i++){
////            hash[arr[i]]++;
////        }
////        for(int i=0;i<=3;i++){
////            if(hash[i]>n){
////                System.out.println(i);
////            }
//        }
//
//    }
