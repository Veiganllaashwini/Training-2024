public class lcss {
    public static int solve(int i,int j,String s1,String s2,int[][] dp,StringBuilder sc) {
        if (i == 0) {
            for (j = 0; j <= s2.length(); i++) {
                dp[0][j] = 0;
            }
        }
        if (j == 0) {
            for (i = 0; i <= s1.length(); i++) {
                dp[i][0] = 0;
            }
        } else {
            for (i = 1; i <= s1.length(); i++) {
                for (j = 1; j <= s2.length(); j++) {
                    if (s1.charAt(i - 1) == s2.charAt(j - 1)) {
                        dp[i][j] = 1 + dp[i - 1][j - 1];
                    } else {
                        dp[i][j] = Math.max(dp[i - 1][j], dp[i][j - 1]);
                    }
                }
            }}
        for(i=s1.length();i>=1;i++){
            for(j=s2.length();j>=1;j++){
                if(s1.charAt(i-1)==s2.charAt(j-1)){
                    dp[i][j]=1+dp[i-1][j-1];
                    sc.append(s1.charAt(i));
                }
                else{
                    dp[i][j]=Math.max(dp[i-1][j],dp[i][j-1]);
                }
            }
        }

            return dp[s1.length()][s2.length()];
        }


    public static void main(String[] args) {
        String s1="abxca";
        String s2="xza";
        int n=s1.length();
        int i=0,j=0;
        int m=s2.length();
        int[][] dp=new int[n+1][m+1];
//        for( i=0;i<=n;i++){
//            for(j=0;j<=m;j++){
//                dp[i][j]=-1;
//            }
//        }
//        for(int i=0;i<=n;i++){
//            dp[i][0]=0;
//        }
//            for(int j=0;j<=m;j++){
//                dp[0][j]=0;
//            }

        StringBuilder sc=new StringBuilder();
        int x=solve(s1.length(),s2.length(),s1,s2,dp,sc);
//        for(int i=0;i<=n;i++) {
//            for (int j = 0; j <= m; j++) {
//                dp[0][j] = 0;
//            }
//        }
//        for(int i=0;i<=n;i++){
//            for(int j=0;j<=m;j++){
//                dp[i][0]=0;
//            }
//        }

        System.out.println(x);
        for(i=0;i<=n;i++){
            System.out.println();
            for(j=0;j<=m;j++){
                System.out.print(dp[i][j]+" ");
            }
        }

//
//        while(i!=s1.length() && j!=s2.length()){
//            if(s1.charAt(i-1)==s2.charAt(j)){
//                sc.append(s1.charAt(i-1));
//                i--;
//                j--;
//            }
//            else{
//                if(s1.charAt(i)==s2.charAt(j-1)){
//                    j--;
//                }
//                else{
//                    i--;
//                }
//
//            }

//        }
        System.out.println(sc);
    }
}
