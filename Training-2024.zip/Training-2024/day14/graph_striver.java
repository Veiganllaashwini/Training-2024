import java.util.*;
//public class graph_striver {
//
//    public static ArrayList<Integer> bfsOfGraph(int v,ArrayList<List<Integer>> adj){
//
//        ArrayList < Integer > bfs = new ArrayList < > ();
//        boolean vis[] = new boolean[v];
//        Queue < Integer > q = new LinkedList < > ();
//        q.add(0);
//        vis[0]=true;
//        while(!q.isEmpty()){
//int node=q.remove();
//bfs.add(node);
//for(int ele:adj.get(node)){
//    if(vis[ele]==false){
//        vis[ele]=true;
//        q.add(ele);
//    }
//}
//
//
//        }
//        return bfs;
//
//
//    }
//    public static void main(String[] args) {
//     ArrayList<List<Integer>>  adj=new ArrayList<>();
//     for(int i=0;i<5;i++){
//         adj.add(new ArrayList<>());
//     }
//        adj.get(0).add(1);
//        adj.get(1).add(0);
//        adj.get(0).add(4);
//        adj.get(4).add(0);
//        adj.get(1).add(2);
//        adj.get(2).add(1);
//        adj.get(1).add(3);
//        adj.get(3).add(1);
//        for(List ele: adj){
//            System.out.println(ele);
//        }
//
//        graph_striver s=new graph_striver();
//        ArrayList < Integer > ans = s.bfsOfGraph(5, adj);
//        System.out.println(ans);
//        for(int ele:ans){
//            System.out.println(ele);
//        }
//
//    }
//}
public class graph_striver{
    public static ArrayList<Integer> bfs(ArrayList<ArrayList<Integer>> adj,int currr){
        Queue<Integer> q=new LinkedList<>();
        boolean visited[]=new boolean[adj.size()];
        ArrayList<Integer> ds=new ArrayList<>();
        q.add(currr);
        visited[currr]=true;
        while(!q.isEmpty()){
            int curr=q.poll();
            ds.add(curr);
            for(int ele:adj.get(curr)){
                if(visited[ele]==false){
                    visited[ele]=true;
                    q.add(ele);
                }
            }
        }
        return ds;

    }
    public static void dfs(ArrayList<ArrayList<Integer>> adj,boolean visited[],int curr){
        System.out.println(curr);
        visited[curr]=true;
        for(int ele:adj.get(curr)){
            if(visited[ele]==false){
                dfs(adj,visited,ele);
            }

        }



    }


    public static void main(String[] args) {
        graph_striver g=new graph_striver();
        ArrayList<ArrayList<Integer>> adj=new ArrayList<>();
        int v=6;
        for(int i=0;i<v;i++){
            adj.add(new ArrayList());
        }
        ArrayList<Integer> ds=new ArrayList<>();
                adj.get(0).add(2);
                adj.get(2).add(0);
                adj.get(1).add(4);
                adj.get(4).add(1);
//        adj.get(1).add(0);
//        adj.get(0).add(4);
//        adj.get(4).add(0);
//        adj.get(1).add(2);
//        adj.get(2).add(1);
//        adj.get(1).add(3);
//        adj.get(3).add(1);
        System.out.println("DFS TRAVERSAL--->");
//        System.out.println(g.bfs(adj));
        boolean visited[]=new boolean[v];
        for(int i=0;i<adj.size();i++){
            if(visited[i]==false){
                dfs(adj,visited,i);
            }
        }
        for(int i=0;i<adj.size();i++){
            visited[i]=false;
        }
        for(int i=0;i<adj.size();i++){
            if(visited[i]==false){
                System.out.println(  bfs(adj,i));

            }
        }

//        dfs(adj,visited,0);



    }
}