public class da1_1 {
    public static void main(String[] args) {
        String str = "aaabbbaaaaaddddc";
        String str1 = "";
        int n = str.length();
        StringBuilder s = new StringBuilder();
        int cnt = 1;
        int k = 0;
        char x=' ';
        int i;
        for (i = 0; i < n - 1; i++) {
             x = str.charAt(i);
            if (str.charAt(i) == str.charAt(i + 1)) {
                cnt++;
            } else {
                s.append(x + "-" + cnt+"\n");
                cnt = 1;
            }
        }
        s.append(x+"-"+cnt+"\n");
        System.out.println(s);

    }}