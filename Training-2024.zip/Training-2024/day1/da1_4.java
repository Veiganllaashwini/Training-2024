public class da1_4 {
    public static void main(String[] args) {
        String str="placements";
        int i=0;
        int n=str.length();
        while (i < n) {
            char x = str.charAt(i);
            if (x >= 97 && x <= 122)
            {
                if (x == 'a' || x == 'e' || x == 'i' || x == 'o' || x == 'u') {
                    int s=x-32;
                    System.out.println((char)s);
                    System.out.println(str.replace(str.charAt(i),(char)s));
                }
                i++;
    }
            i++;
}
        System.out.println(str);
    }}
