import java.util.*;
public class da1_5 {
    public static void main(String[] args) {
        String s;
        Scanner sc=new Scanner(System.in);
        s=sc.next();
        int n=s.length();
        int i=0;
        int es=0;
        int os=0;
        while(i<n){
            if(s.charAt(i)>=48 && s.charAt(i)<=57){
                char x=s.charAt(i);
                System.out.println(s.charAt(i));
                System.out.println(x);
                if((x-48)%2==0){
                    es=es+1;
                }
                else{
                    os=os+1;
                }
                i++;
            }
        }
        System.out.println("esum"+es);
        System.out.println("odd"+os);
    }
}
