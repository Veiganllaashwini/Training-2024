import java.util.*;
public class da1_6 {
    public static boolean prime(int n){
        boolean flag=true;
        int cnt = 0;
        for (int i = 1; i <= n; i++) {
            if (n % i == 0) {
                cnt++;
            }
        }
        if (cnt == 2) {
            return true;
        }
        else{
            return false;
        }
    }
    public static void main(String[] args) {
        int cnt=0;
        Scanner sc = new Scanner(System.in);
        int x = sc.nextInt();
        int rem=0;
        while(x!=0) {
            rem = x % 10;
            if (prime(rem) == true) {
                cnt++;
            }
            x = x / 10;
        }
//        while()
//        boolean flag=true;
//        if(prime(x)==true){
//            System.out.println(x);
//        }
//        else{
//            while(prime(x)!=true){
//                x++;
//            }
//               System.out.println(x);
//        }
        System.out.println(cnt);
    }
}
