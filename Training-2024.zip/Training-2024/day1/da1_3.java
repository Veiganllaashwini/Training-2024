public class da1_3 {
    public static void main(String[] args) {
        String str = "af46feaEioUgh29@iO*";
        int n = str.length();
        System.out.println(n);
        int i = 0;
        int lv = 0, uv = 0;
        int lc = 0, uc = 0;
        int digit = 0;
        int sc=0;
        while (i < n) {
            char x = str.charAt(i);
            if (x >= 97 && x <= 122)
                {
                    if (x == 'a' || x == 'e' || x == 'i' || x == 'o' || x == 'u') {
                        lv++;
                    }
                    else{
                        lc++;
                    }
                    i++;

                }
            else if(x>=65 && x<=90){
                if (x == 'A' || x == 'E' || x == 'I' || x == 'O' || x == 'U') {
                    uv++;
                }
                else{
                    uc++;
                }
                i++;
            }
            else if(x>=48 && x<=57){
                digit++;
                i++;
            }
                else{
                    sc++;
                i++;
            }}
        System.out.println("lv"+ lv);
        System.out.println("uv"+ uv);
        System.out.println("lc"+ lc);
        System.out.println("uc"+ uc);
        System.out.println("digit"+ digit);
        System.out.println("sc"+ sc);


    }
        }

