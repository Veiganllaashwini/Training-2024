import java.util.*;
public class da1_7 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String s=sc.next();
        int n=s.length();
        int ans=0;
        int i=0;
        int cnt1=0;
        int cnt2=0;
        int cnt3=0;
        int cnt4=0;
      while(i<n){
          char x=s.charAt(i);
if(x>=97 && x<=122){
    cnt1++;
}
else if(x>=65 && x<=90){
   cnt2++;
}
else if(x>=48 && x<=57){
    cnt3++;
}
else{
    cnt4++;
}
i++;
      }
      if(cnt1==0){
          ans+=1;
      }
      if(cnt2==0){
          ans+=1;
      }
      if(cnt3==0){
          ans+=1;
      }
      if(cnt4==0){
          ans+=1;
      }
if(n+ans<8){
    ans=8-n;
}
if(ans==0){
    ans=-1;
}
System.out.println(ans);
    }
}
