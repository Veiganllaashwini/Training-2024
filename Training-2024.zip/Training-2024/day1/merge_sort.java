public class merge_sort {
    public static int merge(int low,int mid,int high,int[] arr){
int cnt=0;
        int i=low;
        int j=mid+1;
        int k=low;
        int b[]=new int[high+1];
        while(i<=mid && j<=high){
            if(arr[i]<=arr[j]){
                b[k]=arr[i];
                k++;
                i++;
            }
            else {
                cnt+=(mid-i)+1;
                b[k]=arr[j];
                k++;
                j++;
            }

        }
        while(i<=mid){
            b[k]=arr[i];
            k++;
            i++;
        }
        while(j<=high){
            b[k]=arr[j];
            k++;
            j++;
        }
        for( i=low;i<=high;i++){
            arr[i]=b[i];
        }
return cnt;



    }

    public static int mergesort(int low,int high,int[] arr){
        int cnt=0;
        int mid=(low+high)/2;
        if(low<high){
            cnt+=mergesort(low,mid,arr);
//            merge(low,mid,high,arr);

           cnt+= mergesort(mid+1,high,arr);
            cnt+=merge(low,mid,high,arr);


        }
        else{
            return 0;
        }
        return cnt;
    }
    public static void main(String[] args) {
        int[] arr={2, 3, 4, 5, 6};
        int n=arr.length;
        System.out.println(mergesort(0,n-1,arr));
        for(int x:arr){
            System.out.print(x+" ");
        }
    }
}
