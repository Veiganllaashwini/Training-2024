public class day2_4 {
    public static void main(String[] args) {
        String s="MMFFMFMFMFMM";
        int cnt=0;
        int m=0;
        int f=0;
        int n=s.length();


//        for(int i=0;i<n;i++){
//            if(s.charAt(i)=='F')
//                f++;
//        }
//        m=n-f;
        //        if(f==m)
//            System.out.println("0");
//        else if(f>m)
//            System.out.println("f");
//        else System.out.println("m");
        for(int i=0;i<n;i++){
            if(s.charAt(i)=='F'){
                cnt++;
            }
            else{
                cnt--;
            }
        }

        if(cnt==0)
            System.out.println("0");
        else if(cnt>0){
            System.out.println("f");
        }
        else if(cnt<0){
            System.out.println("m");
        }
    }
}
