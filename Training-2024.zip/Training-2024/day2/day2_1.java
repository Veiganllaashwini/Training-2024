public class day2_1 {
    public static int fun(int num){
        int sum=0;
        int rem;
        while(num!=0) {
            rem = num % 10;
            sum = sum + rem;
//            System.out.println(sum);
            num = num / 10;
        }
        return sum;}


    public static int sum_digits(int n){
        int num=n;
        int rem;
        int sum=0;
        int s;

        if(n<10){
            return n;
        }
      else{

          while(true){
              int x=fun(n);
              if(x<10){
                  return x;
              }
              n=x;
          }

        }

    }
    public static boolean isPrime (int n){
        int cnt=0;
for(int i=1;i<=n;i++){
    if(n%i==0){
        cnt++;
    }

}
if(cnt==2){
    return true;
}
return false;
    }

    public static void main(String[] args) {
        int n=163;
        int num=n;
        int x=sum_digits(n);
//        while(sum_digits(n)<10 && !(isPrime(sum_digits(n)))){
//            n=n+1;
//        }
        while(x<10 && !(isPrime(x))){//instead of isprime..you can put 2,3,5,7
            n=n+1;
            x=sum_digits(n);

        }
        System.out.println(n);

//        System.out.println("hello");
//        int x=sum_digits(n);
//        if(isPrime(x))
//            System.out.println(num);


















    }
}
