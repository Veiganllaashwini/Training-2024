//to find length of array...but us should try it using n/2 time
public class day2_3 {

//    public static int fun(int n,int sum){
//        if(n==0){
//            return sum;
//        }
//        else{
//            if(n%2==0)
//                sum=sum+n;
//            return fun(n-1,sum);
//
//
//        }
//
//    }
    public static boolean fun(int n){
        if(n%2==0)
            return true;
        return false;
    }
    public static void main(String[] args) {
//        int n=10;
//        System.out.println(fun(n,0));
        int arr[]={1,2,3,4,5};
        int n=arr.length;
        System.out.println(fun(n));
    }
}
