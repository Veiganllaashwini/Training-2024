import java.util.*;
public class day2_5
{
    public static void main(String[] args) {
        Stack<Character> st=new Stack<>();
        String s="leet**code*e";
//        ArrayList<Character> ds=new ArrayList<>();
//        for(int i=0;i<s.length();i++){
//
//            ds.add(s.charAt(i));
//        }
//        for(int i=0;i<s.length()-1;i++){
//            if(s.charAt(i)!='*' && s.charAt(i+1)=='*' ){
//
//                ds.remove(i);
//                ds.remove(i+1);
//                solve(ds);
//            }
            for(int i=0;i<s.length();i++){
                char x=s.charAt(i);
                if(x!='*'){
                    st.push(s.charAt(i));
                }
                else if(x=='*'){
                    st.pop();
                }

        }
            while(!st.isEmpty()){
                System.out.print(st.pop()+" ");
            }


    }
}
