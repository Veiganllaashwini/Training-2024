import java.util.*;
public class day2_6 {
    public static void main(String[] args) {
        String s="is2 sentence4 This1 a3";
Stack<Character> st=new Stack<>();
ArrayList<Character> s11=new ArrayList<>();
for(int i=0;i<s.length();i++){
    String s1;
if(s.charAt(i)==1){
    i--;
    while(s.charAt(i)!=' '){
        st.push(s.charAt(i));
    }
   s11.add(st.pop());

}

}
        System.out.println(s11);
    }
}

///Totallyyyyy incompleteeeee

