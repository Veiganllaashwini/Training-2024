//problem is to print even sum from arr1...odd sum from arr2

import java.util.*;
public class day2_2 {

    public static List<Integer> summ(List<Integer> s,int ind,int osum,int esum,int[]arr1,int[] arr2){
        if(ind==arr1.length && ind==arr2.length){
          s.add(esum);
          s.add(osum);
          return s;
        }
        if(arr1[ind]%2==0){
            esum=esum+arr1[ind];

        }
        if(arr2[ind]%2==1){
            osum=osum+arr2[ind];
        }

        return summ(s,ind+1,osum,esum,arr1,arr2);

    }
//    public static int oddsum(int ind,int sum,int[] arr1){
//        if(ind==arr1.length){
//            return sum;
//        }
//        if(arr1[ind]%2==1){
//            sum=sum+arr1[ind];
//        }
//        return oddsum(ind+1,sum,arr1);
//
//    }
//    public static int evensum(int ind,int sum,int[] arr1){
//        if(ind==arr1.length){
//            return sum;
//        }
//        if(arr1[ind]%2==0){
//            sum=sum+arr1[ind];
//        }
//        return evensum(ind+1,sum,arr1);
//
//    }
    public static void main(String[] args) {
      ArrayList<Integer> arr=new ArrayList<>();
        int arr1[]={3,8,5,4,3};
        int arr2[]={5,0,9,3,2};
//        arr.add(evensum(0,0,arr1));
//        arr.add(oddsum(0,0,arr2));
        System.out.println(summ(arr,0,0,0,arr1,arr2));
//        System.out.println(arr);
    }

}
