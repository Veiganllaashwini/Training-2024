import java.util.*;
public class detect_cycle {
    static class Node{
        int curr;
        int parent;

        Node(int x,int y){
            this.curr=x;
            this.parent=y;
        }

    }
    public static boolean cycle_dfs(ArrayList<ArrayList<Integer>> adj,boolean visited[],int curr,int parent) {
        visited[curr] = true;
        for (int ele : adj.get(curr)) {
            if (visited[ele] == false) {
                boolean x = cycle_dfs(adj, visited, ele, curr);
                if (x == true) {
                    return true;
                }
            } else if (ele != parent) {
                return true;
            } else {
                return false;
            }
        }
            return false;
        }
        public static void bipartite(ArrayList<ArrayList<Integer>> adj,int curr){
int flag=0;
            Queue<Integer>q=new LinkedList<>();
//            boolean visited[]=new boolean[adj.size()];
            int[] arr=new int[adj.size()];
            Arrays.fill(arr,-1);
            q.add(curr);
//            visited[curr]=true;
            arr[curr]=0;
            while(!q.isEmpty()) {
                int x = q.remove();
                for (int ele : adj.get(x)) {
                    if (arr[ele]==-1) {
                        if(arr[x]==0){
                            arr[ele]=2;
                        }
                        else{
                            arr[ele]=0;
                        }
                        q.add(ele);
                    }
                    else if (arr[ele] == arr[x]) {
                        flag = 1;
                        break;
                    }

                }
                if(flag==1)
                    break;
            }
                if(flag==1)
                    System.out.println("yes");
                else
                System.out.println("no");



            }







    public static boolean cycle_bfs(ArrayList<ArrayList<Integer>> adj){

        Queue<Node> q=new LinkedList<>();
        boolean visited[]=new boolean[adj.size()];
        q.add(new Node(1,-1));
        visited[1]=true;
        while(!q.isEmpty()){
            int node=q.peek().curr;
            int par=q.peek().parent;
            q.remove();
            for (int ele:adj.get(node)){
                if(visited[ele]==false){
                    visited[ele]=true;
                    q.add(new Node(ele,par));
                }
                else if(ele!=par){
                    return true;
                }

            }

        }
        return false;



    }
    public static void main(String[] args) {
        detect_cycle c=new detect_cycle();
ArrayList<ArrayList<Integer>> adj=new ArrayList<>();
for(int i=0;i<=7;i++){
    adj.add(new ArrayList());
}
//adj.get(1).add(2);
//        adj.get(1).add(3);
//        adj.get(2).add(1);
//        adj.get(2).add(5);
//        adj.get(3).add(1);
//        adj.get(3).add(4);
//        adj.get(3).add(6);
//        adj.get(4).add(3);
//        adj.get(5).add(2);
//        adj.get(5).add(7);
//        adj.get(6).add(3);
//        adj.get(6).add(7);
//        adj.get(7).add(5);
//        adj.get(7).add(6);
       adj.get(1).add(2);
        adj.get(1).add(5);
        adj.get(2).add(1);adj.get(2).add(3);
        adj.get(3).add(2);adj.get(3).add(4);
        adj.get(4).add(3);adj.get(4).add(5);
        adj.get(5).add(1);adj.get(5).add(4);





//    boolean x=c.cycle_bfs(adj);
//    boolean visited[]=new boolean[adj.size()];
//    boolean y=c.cycle_dfs(adj,visited,1,-1);
//        System.out.println(y);
        bipartite(adj,1);


    }
}
