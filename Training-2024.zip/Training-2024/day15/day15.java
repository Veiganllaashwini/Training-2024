public class day15{   //take coins only once..tell if amount is possible
    public static void solve(int i,int j,int[] arr,int n,int[][] dp) {
//        if(i==0){
//            for(j=0;j<=n;j++){
//                dp[i][j]=j;
//            }
//        }
//        int k=1;
//        for(i=1;i<4;i++){
//            for(j=0;j<=n;j++){
//                if(dp[k-1][j]<arr[i]){
//                    dp[i][j]=dp[i-1][j];
////                    dp[i][j]=-1;
//                }
//                else if(dp[k-1][j]>=arr[i]){
//                    dp[i][j]=dp[i][dp[k-1][j]-arr[i]]+1;
//                    dp[i][j]=Math.min(dp[i][j],dp[i-1][j]);
//                }
//            }
//        }
////        System.out.println(dp[3][n]);
        if (i == 0) {
            for (j = 0; j <= n; j++) {
                if (j == 0 || j == arr[i]) {
                    dp[i][j] = 1;
                } else {
                    dp[i][j] = 0;
                }
            }

        }
        for (i = 1; i < arr.length; i++) {
            for (j = 0; j <= n; j++) {
                if (j < arr[i]) {
                    dp[i][j] = dp[i - 1][j];
                } else {
                    if (dp[i - 1][j] == 1) {
                        dp[i][j] = 1;
                    } else {
                        dp[i][j] = dp[i - 1][j - arr[i]];
                    }
                }
            }
        }
    }
    public static void main(String[] args) {
        int arr[]={2,3,5,6};
        int n=11;
        int dp[][]=new int[arr.length][n+1];
        solve(0,0,arr,n,dp);
        for(int i=0;i<arr.length;i++){
            System.out.println();
            for(int j=0;j<=n;j++){
                System.out.print(dp[i][j]+" ");
            }
        }
    }
        }
