public class day15_2 {
    public static int solve(int i,int j,int[][] arr){
        int n=arr.length;
        int m=arr[0].length;
        if(i==n-1 && j==m-1){
            return 1;
        }
        if(i>=n || j>=m){
            return 0;
        }
        else{
            int down=solve(i+1,j,arr);
            int right=solve(i,j+1,arr);
            return down+right;
        }
    }
    public static void main(String[] args) {
        int n=4;
        int m=3;
        int arr[][]=new int[n][m];
        for(int i=0;i<n;i++){
            for(int j=0;j<m;j++){
                arr[i][j]=0;
            }
        }
        System.out.println(solve(0,0,arr));
    }
}
