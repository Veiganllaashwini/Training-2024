import java.util.*;
public class day15_3 {

//    public static void dfs(ArrayList<ArrayList<Integer>> adj,int curr,boolean visited[],String s){
//        if(curr==2){
//            System.out.println(s);
//            return;
//        }
//
//        for(int ele:adj.get(curr)){
//            if(visited[ele]==false)
//            visited[ele]=true;
//            dfs(adj,curr,visited,s+ele);visited[ele]=false;
//        }
//    }
    public static void dfss(ArrayList<ArrayList<Integer>> adj, boolean visited[], int curr, int target, String path){
        if(curr==1){
            System.out.println(path);
            return;
        }

        for(int ele: adj.get(curr)){
            if(visited[ele]==false){
                visited[curr]=true;
                dfss(adj,visited,ele,target,path+ele);
                visited[curr]=false;
            }
        }
    }

    public static void main(String[] args) {
        ArrayList<ArrayList<Integer>> adj=new ArrayList<>();
        int v=3;
        for(int i=0;i<v;i++){
            adj.add(new ArrayList());
        }
        adj.get(0).add(1);
        adj.get(1).add(0);
        adj.get(2).add(1);
        adj.get(1).add(2);
//        adj.get(2).add(3); adj.get(3).add(2);
        boolean visited[]=new boolean[v];
        String s=" ";
        dfss(adj,visited,0,2,s);

    }
}
