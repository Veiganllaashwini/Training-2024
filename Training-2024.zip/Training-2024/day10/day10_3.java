import java.util.ArrayList;
import java.util.HashMap;

public class day10_3 {
    public static void main(String[] args) {
        String s="hello:9438,car:214,book:8799,apple:2187";
        //output:oaxp
        int i=0;
        int n=s.length();
        int k=0;
        ArrayList<Character> ds=new ArrayList<>();
        while(i<n){
            int min=0;
            char x=s.charAt(i);
            while(s.charAt(i)!=':'){
                ds.add(s.charAt(i));
                i++;
            }
            i++;
            int y=ds.size();
            while(s.charAt(i)!=',') {
                min = (s.charAt(i)) - 48;
//                System.out.println("min" + min);
                if(min>y){
i++;
                }
                else if (min == y) {
                    System.out.println(ds.get(ds.size() - 1));
                } else {
                    i++;
                    if ((min < y)) {
                        min = Math.min(y, min);
                    }
                }

            }
            if(min<y){
                System.out.println(ds.get(y));
            }
            i++;
            System.out.println(min);
            ds.clear();



        }

    }
}
