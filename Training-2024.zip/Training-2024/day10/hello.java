public class hello {
    public static void main(String[] args) {
        int arr[] = {4, 9, 8, 2, 14, 3, 5, 6};
        int n = arr.length;
        int i=0;
while(i<n-2){

        if (arr[i] > arr[i + 1]) {
            int temp = arr[i];
            arr[i] = arr[i + 1];
            arr[i + 1] = temp;

        }
        if (arr[i + 1] > arr[i + 2]) {
            int temp = arr[i + 1];
            arr[i + 1] = arr[i + 2];
            arr[i + 2] = temp;

        }
        if (arr[i] > arr[i + 1]) {
            int temp = arr[i];
            arr[i] = arr[i + 1];
            arr[i + 1] = temp;

        }
        i++;

    }


        for (i = 0; i < n; i++) {
            System.out.print(arr[i] + " ");
        }
    }
}

