import java.util.*;
public class day10_2 {
    public static void main(String[] args) {
        int arr[]={4,9,8,2,14,3,5,6};
        int i=0;
        int j=0;
        int n=arr.length;
//        for( i=0;i<n;i++){
//            System.out.println(arr[i]);
//        }
        ArrayList<Integer> ds=new ArrayList<>();
        while(i<n-2){
            j=i;
            ds.add(arr[j]);
            ds.add(arr[j+1]);
            ds.add(arr[j+2]);
            Collections.sort(ds);
            System.out.println(ds);
                arr[j]=ds.get(0);
                arr[j+1]=ds.get(1);
                arr[j+2]=ds.get(2);
                ds.clear();
            i++;
            }


        for( i=0;i<n;i++){
            System.out.print(arr[i]+" ");
        }
    }
}
