import java.util.Stack;

public class stack_linkedlist {
    class Node{
        int data;
        Node next=null;
        Node(int data){
            this.data=data;
            this.next=null;
        }


    }
    public static Node head=null;
    public  boolean isEmpty(){

        return head==null;

    }
    public void push(int data)
    {
        Node newnode=new Node(data);
        if(isEmpty()){
            head=newnode;
            return;
        }
        newnode.next=head;
        head=newnode;}



    public int pop(){
        if(isEmpty())
            return -1;
        else{

            int top=head.data;
            head=head.next;
            return top;
        }
    }

    public int peek(){
        return head.data;

    }


    public static void main(String[] args) {
        stack_linkedlist  s=new stack_linkedlist ();
        s.push(100);
        s.push(20);
        s.push(30);
        s.push(40);
        while(s.isEmpty()!=true){
            System.out.println(s.peek());
            s.pop();
            
        }


    }
}
