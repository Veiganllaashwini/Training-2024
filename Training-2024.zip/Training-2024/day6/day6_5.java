public class day6_5 {
    public static int solve(int n,int[] arr){
        if(n==0){
            return arr[0];
        }
        if(n<0){
            return 0;
        }
        int x=arr[n]+solve(n-2,arr);
        int y=0+solve(n-1,arr);
        return Math.max(x,y);
    }

    public static void main(String[] args) {
        int[] arr={13,9,4,10,5,7};
        System.out.println(solve(arr.length-1,arr));
    }
}
