import java.util.*;
public class day6_1 {
    public static void solve(int ind,ArrayList<Integer> ds,int[] arr){

        if(ds.size()==3)
        {
            System.out.println(ds);
            return;
        }
        for(int i=ind;i<arr.length;i++){
            ds.add(arr[ind]);
            solve(i+1,ds,arr);
            ds.remove(ds.size()-1);
        }



//        if(ind==arr.length){
//            if(ds.size()==3)
//                System.out.println(ds);
//            return;
//        }
//        ds.add(arr[ind]);
//        solve(ind+1,ds,arr);
//        ds.remove(ds.size()-1);
//        solve(ind+1,ds,arr);
    }

    public static void main(String[] args) {
        int arr[]={3,2,5,6,2,3};
        ArrayList<Integer> ds=new ArrayList<>();
        solve(0,ds,arr);
        System.out.println((Math.log(243)/Math.log(3)));
    }
}
