import java.util.*;

public class day6_4 {
    public static void main(String[] args) {
        ArrayList<Integer> ds=new ArrayList<>();
        String s="polikujmnhytgbvfredcxsqaz";
        int n=s.length();
                String s1="abcd";
        Hashtable<Character,Integer> hs=new Hashtable<>();
        for(int i=0;i<n;i++){
            hs.put(s.charAt(i),i);
        }
        System.out.println(hs);
        for(int i=0;i<s1.length();i++){
            ds.add((hs.get(s1.charAt(i))));

        }
//        System.out.println(hs.values());

        Collections.sort(ds);
        System.out.println(ds);
//        for(int i=0;i<ds.size();i++){
//            System.out.println(hs.get(ds.get(i)));
//
//        }




    }
}
