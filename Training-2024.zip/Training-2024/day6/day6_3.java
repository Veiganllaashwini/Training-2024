import java.util.ArrayList;

public class day6_3 {
    public static void solve(int n,int ind,ArrayList<Integer> ds,int sum,int[] arr) {
        if (ind == arr.length) {
            if (sum == n && ds.size() == 2) {
                System.out.println(ds);
            }
            return;
        }
        ds.add(arr[ind]);
        solve(n,ind + 1, ds, sum + arr[ind], arr);
        ds.remove(ds.size() - 1);
        solve(n,ind + 1, ds, sum, arr);
    }
    public static boolean isPrime(int n){
        int cnt=0;
        int flag=0;
        for(int i=2;i<=n/2;i++){
            if(n%i==0){
                flag=1;
                break;
            }
        }
        if(flag==0)
            return true;
        return false;
    }

    public static void main(String[] args) {
ArrayList<Integer> ds=new ArrayList<>();
        int n=48;
        ds.add(1);
        for(int i=1;i<=n;i++){
            if(isPrime(i))
                ds.add(i);
        }
//        System.out.println(ds);
        int sizee=ds.size();
        int arr[]=new int[sizee];
        for(int i=0;i<sizee;i++){
            arr[i]=ds.get(i);
        }
        ds.clear();
        solve(n,0,ds,0,arr);

    }
}
