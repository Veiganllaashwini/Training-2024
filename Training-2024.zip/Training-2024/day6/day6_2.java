//import java.util.*;
//public class day6_2 {
//    public static void main(String[] args) {
////        ArrayList<Character> ds=new ArrayList<>();
////ArrayList<List<Character>> ans=new ArrayList<>();
//        String s="school";
//        int i=0;
//        int cnt=0;
//        String x1="";
////        while(i<s.length()-2){
////            ds.add(s.charAt(i));
////            ds.add(s.charAt(i+1));
////            ds.add(s.charAt(i+2));
////            ans.add(new ArrayList(ds));
////            ds.clear();
////            i++;
////        }
////        System.out.println(ds);
////        System.out.println(ans);
//        int x=2;
//        int y=3;
//        int z=1;
////        StringBuilder sc=new StringBuilder();
//            x1=x1+(s.charAt(x));
//            x1=x1+(s.charAt(y));
//            x1=x1+(s.charAt(z));
//        System.out.println(x1);
//        System.out.println(x1.charAt(1));
//        int k=0;
//        while(k<=3){
//        if(s.contains()){
//            cnt++;
//        k++;}
//        else{
//            break;
//        }
//        }
//        if(cnt==3){
//            System.out.println("yes");
//        }
//        else{
//            System.out.println("no");
//        }
//
////        System.out.println(sc);
////        if(ans.contains(l)){
////            System.out.println("yes");
////        }
////        else{
////            System.out.println("no");
////        }
////        x.
////        int k=0;
////        while(k<=3){
////            if(s.contains(sc.charAt(k)))
////                k++;
////            }
////        }
////      if(s.contains(sc)){
////          System.out.println("yes");
////      }
////      else{
////          System.out.println("no");
////      }
//    }
//}
