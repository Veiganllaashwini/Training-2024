import java.util.*;
public class day4 {
    public static void main(String[] args) {
        String s="abc";
        String t="bca";
        int n=s.length();
        int m=t.length();
        int sum=0;
        Hashtable<Character,Integer> hs=new Hashtable<>();
        Hashtable<Character,Integer> hm=new Hashtable<>();
        for(int i=0;i<n;i++){

            hs.put(s.charAt(i),i);
        }
        for(int i=0;i<m;i++){

            hm.put(t.charAt(i),i);
        }
        for(int i=0;i<n;i++){
            System.out.println(hs.get(s.charAt(i)));
            System.out.println(hm.get(s.charAt(i)));
//            sum=sum+Math.abs(hs.get(s.charAt(i))-hm.get(t.charAt(i)));
//            System.out.println(sum);
        }
    }

}
