import java.util.*;
public class stringg {
    public static void main(String[] args) {
        StringBuilder s = new StringBuilder("the quick brown fox jumps over the lazy dog");
        StringBuilder s1 = new StringBuilder();
        StringBuilder s2 = new StringBuilder("vkbs bs t suepuv");
        Hashtable<Character, Character> hm = new Hashtable<Character, Character>();
        HashSet<Character> hs = new HashSet<>();
        for (int i = 0; i < s.length(); i++) {
            if (hs.contains(s.charAt(i))) {
//                s1.deleteCharAt(i);
//                s1.append(s.charAt(i));
            } else if (s.charAt(i) == ' ') {

            } else {
                hs.add(s.charAt(i));
                s1.append(s.charAt(i));
            }

        }

//        System.out.println(hs);
//        System.out.println(s1);


//        System.out.println((char)97);
        int j = 97;
        for (int i = 0; i < s1.length(); i++) {
            hm.put(s1.charAt(i), (char) j);
            System.out.println();
            j++;
        }
//        for(Map.Entry m:hm.entrySet()){
//            System.out.println(m.getKey()+" "+m.getValue());
//        }

        for (int i = 0; i < s2.length(); i++) {
            if (s2.charAt(i) == ' ') {
                System.out.print(' ');
            } else {
                System.out.print(hm.get(s2.charAt(i))+" ");
            }

        }


    }
}

