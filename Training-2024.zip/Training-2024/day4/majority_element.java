import java.util.*;
public class majority_element {
    public static void main(String[] args) {
        int arr[]={ 75 ,56 ,56, 56 };
        int n=arr.length;

        int max = Arrays.stream(arr).max().getAsInt();
        int min=Arrays.stream(arr).min().getAsInt();
        int hash[]=new int[max+1];
        for(int i=min;i<=max;i++){
            hash[i]=0;
        }

        for(int i=0;i<n;i++){
            hash[arr[i]]++;
        }
//        for(int i=min;i<=max;i++){
//            System.out.println(hash[i]);
//        }

        for(int i=min;i<=max;i++){
            if(hash[i]>n/2){
                System.out.println("ans:"+i);
                break;
            }



        }
    }
}
