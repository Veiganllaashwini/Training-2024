public class queues_linkedlist {
    static class queue {
        static class Node {
            int data;
            Node next;

            Node(int data) {
                this.data = data;
                this.next = null;
            }

        }

        static Node head = null;
        static Node tail = null;
        public static boolean isEmpty(){
            return head==null && tail==null;
        }

        public static void add(int data) {
            Node newnode = new Node(data);
            if (head == null && tail == null) {
                head = newnode;
                tail = newnode;

            } else {
                tail.next = newnode;
                tail = newnode;
            }


        }

        public static Node remove() {
            if (head == null && tail==null) {
                return null;
            }

            else {
                head = head.next;
                return head;

            }
        }

        public static void print() {
            Node ptr = head;
            while (ptr != tail.next) {
                System.out.println(ptr.data);
                ptr = ptr.next;
            }
        }
    }

    public static void main(String[] args) {
        queue l=new queue();
        l.add(10);
        l.add(20);
        l.remove();
        l.add(30);
        l.add(40);
        l.add(50);
        l.remove();
        l.remove();
        l.remove();
        l.remove();
        l.print();
        System.out.println(l.isEmpty());
    }
}
