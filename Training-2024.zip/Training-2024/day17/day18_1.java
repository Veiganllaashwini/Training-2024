import java.util.Scanner;
import java.util.*;

public class day18_1 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        String ss[]=new String[n];
        StringBuilder scc=new StringBuilder();
        int i=0;
        int num[]=new int[n];
        ArrayList<String> ds=new ArrayList<>();
        int j=0;
        while(n!=0){
            String s=sc.next();
             num[j]=sc.nextInt();
            if(num[j]==1){
                ss[i]=s;
            }
            i++;
            j++;
            n--;
        }
        n=num.length;
         i=n-1;
        while(i>=0){
            ds.add(ss[i]);
            i--;
        }
//        System.out.println(ds);
//        for(String s:ss){
//            System.out.println(s);
//        }
        System.out.println(ds);
        int flag=0;
        for( i=0;i<num.length;i++){
            if(num[i]==2){
                System.out.println("number: "+num[i]);
                System.out.println("string: "+ss[i]);
                if(ds.contains(ss[i])){
                    System.out.println("true");
                }
                else{
                    System.out.println("false");
                }
            }

//            else if(num[i]==3){
//                for(String ele:ss){
//                    if(ele.contains(ss[i])){
//                        flag=1;
//                        System.out.println("true");
//                        break;
//                    }
//                }
//                System.out.println("false");
//
//            }
        }

    }
}
