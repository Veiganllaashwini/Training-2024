public class Trie {
    static class Node {
//HashMap<Character,Node> hs;
        Node links[] = new Node[26];
        boolean flag = false;

        public boolean containsKey(char ch) {
            return links[ch - 'a'] != null;
        }
        void setEnd() {
            flag = true;
        }
        Node get(char ch) {
            return links[ch - 'a'];
        }

        void put(char ch, Node node) {
            links[ch - 'a'] = node;
        }
    }
        private Node root;
        public Trie(){
            root=new Node();
        }


        public void insert(String s) {
            Node ptr = root;
            for (int i = 0; i < s.length(); i++) {
                if (!ptr.containsKey(s.charAt(i))) {
                    ptr.put(s.charAt(i), new Node());
                }
                ptr = ptr.get(s.charAt(i));
            }
            ptr.setEnd();
        }


//         if(ptr==null){
//             ptr.hs.put(s.charAt(i),null);
//        }


        public static void main(String[] args) {
            Trie t = new Trie();
            t.insert("hellooo");
            t.insert("heyaa");
        }
    }
