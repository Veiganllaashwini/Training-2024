public class oops {
    static class one{
public static void fun1(){
    System.out.println("hello");
}

    }
    static class two extends one{
        static void fun1(int x){
            System.out.println("heyy");
            System.out.println(x);
        }
    }
    public static void main(String[] args) {
        one o=new one();
        two t=new two();
        t.fun1(10);
    }
}
