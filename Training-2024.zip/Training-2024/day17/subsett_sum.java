import java.util.*;

public class subsett_sum {
    public static void solve(int ind,int sum,ArrayList<Integer> ds,int [] arr,ArrayList<Integer> ans) {
        if (ind == arr.length) {
            ans.add(sum);
            return ;
        }


        else{
            ds.add(arr[ind]);
            sum=sum+arr[ind];
            solve(ind+1,sum,ds,arr,ans);
            ds.remove(ds.size()-1);
            sum=sum-arr[ind];
            solve(ind+1,sum,ds,arr,ans);


        }
    }
    public static void main(String[] args) {
        int arr[]={2,3};
        ArrayList<Integer> ds=new ArrayList<>();
        ArrayList<Integer> ans=new ArrayList<>();
        int target=4;
        solve(0,0,ds,arr,ans);
        Collections.sort(ans);
        System.out.println(ans);
    }
}
