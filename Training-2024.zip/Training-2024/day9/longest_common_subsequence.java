public class longest_common_subsequence {

    public static int solve(int i,int j,String s1,String s2){

        if(i<0 || j<0){
            return 0;}


        if(s1.charAt(i)==s2.charAt(j)){
            return 1+solve(i-1,j-1,s1,s2);

        }
        int left=0+solve(i-1,j,s1,s2);
       int right= 0+solve(i,j-1,s1,s2);
       return Math.max(left,right);


    }




    public static void main(String[] args) {
        String s1="ashwinii";
        String s2="sashiini";
        System.out.println(solve(s1.length()-1,s2.length()-1,s1,s2));

    }
}
