
     class Trees{
        static class Node{

            int data;
            Node left;
            Node right;
            Node(int data){
                this.data=data;
                this.left=null;
                this.right=null;
            }


        }
         static Node root=null;
        public static Node insert(Node root,int val){

            if(root==null){
                root=new Node(val);
                return root;
            }
            if(val<root.data){
                root.left=insert(root.left,val);
            }
            else if(val>root.data){
                root.right=insert(root.right,val);
            }
            return root;
        }
         public static void preorder(Node root){

             if(root==null)
                 return;
             System.out.print(root.data+" ");
             preorder(root.left);

             preorder(root.right);
         }
         public static int  sum(Node root){

            if(root==null){
                return 0;
            }

            int left=sum(root.left);
            int right=sum(root.right);
            return left+right+root.data;


         }
         public static int evensum(Node ptr){
            if(ptr==null)
                return 0;
            int left=evensum(ptr.left);
            int right=evensum(ptr.right);
            if(ptr.data%2==0){
                return left+right+ptr.data;
            }
            return left+right;
         }
         public static int even_odd_sum(Node ptr) {
             if (ptr == null)
                 return 0;
             if (ptr.data % 2 == 0) {
                 return ptr.data + even_odd_sum(ptr.left) + even_odd_sum(ptr.right);
             }
             return -ptr.data+even_odd_sum(ptr.left) + even_odd_sum(ptr.right);
         }
         public static int height(Node ptr){
            if(ptr==null){
                return -1;
            }
//            int left=height(ptr.left);
//            int right=height(ptr.right);
            return Math.max(height(ptr.left),height(ptr.right))+1;
         }
         public static boolean balanced(Node ptr){

            return Math.abs(height(ptr.left)-height(ptr.right))<=1;

         }

     public static int leaf(Node ptr){

            if(ptr==null){
                return 0;
            }
            if(ptr.left==null && ptr.right==null){
                return 1;
            }
            int left=leaf(ptr.left);
            int right=leaf(ptr.right);
            return left+right;

     }

     public static boolean search(Node ptr,int val){
            if(ptr==null)
                return false;
            if(ptr.data==val){
                return true;
            }
            if(val<ptr.data){
                return search(ptr.left,val);
            }
           return search(ptr.right,val);

     }
         public static int leaf_sum(Node ptr){

             if(ptr==null){
                 return 0;
             }
             if(ptr.left==null && ptr.right==null){
                 return ptr.data;
             }
             int left=leaf_sum(ptr.left);
             int right=leaf_sum(ptr.right);
             return left+right;

         }
         public static int oddsum(Node ptr){
             if(ptr==null)
                 return 0;
             int left=oddsum(ptr.left);
             int right=oddsum(ptr.right);
             if(ptr.data%2==1){
                 return left+right+ptr.data;
             }
             return left+right;
         }
        public static void inorder(Node root){

            if(root==null)
                return;
            inorder(root.left);
            System.out.print(root.data+" ");
            inorder(root.right);
        }
         public static void postorder(Node root){
             if(root==null)
                 return;
             postorder(root.left);

             postorder(root.right);
             System.out.print(root.data+" ");
         }
         public static int  max(Node ptr){
            if(ptr==null){
                return Integer.MIN_VALUE;
            }
            int left=max(ptr.left);
            int right=max(ptr.right);
            return Math.max(Math.max(left,right),ptr.data);

         }
         public static int depth(Node ptr,int val,int cnt){
            if(search(ptr,val)){
                if(ptr.data==val){
                    return cnt;
                }
                cnt++;
if(ptr.data>val){
                int left=cnt+depth(ptr.left,val,cnt);}
else{
                 int right=cnt+depth(ptr.right,val,cnt);}





            }
            return -1;


         }





    public static void main(String[] args) {
        Trees b=new Trees();
        root=b.insert(root,10);
        root=b.insert(root,5);
        root=b.insert(root,20);
        root=b.insert(root,2);
//        root=b.insert(root,1);
//        root=b.insert(root,3);
//        root=b.insert(root,15);
        root=b.insert(root,7);
        b.inorder(root);
        System.out.println();
        b.preorder(root);
        System.out.println();
        b.postorder(root);
        System.out.println("sum: "+b.sum(root));
        System.out.println("evensum: "+b.evensum(root));
        System.out.println("oddsum: "+b.oddsum(root));
        System.out.println(even_odd_sum(root));
        System.out.println(height(root));
        System.out.println(balanced(root));
        System.out.println(leaf(root));
        System.out.println(max(root));
        System.out.println(leaf_sum(root));
        System.out.println(search(root,-1));
        System.out.println(depth(root,2,0));

    }
}
