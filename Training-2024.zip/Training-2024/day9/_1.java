package day10;

public class _1 {
    public static int largest(int[] arr,int x,int y ){
        int cnt=0;
        int max=0;
        for(int i=x+1;i<=y-1;i++) {
             cnt=0;
            for (int j = 1; j <= i; j++) {
                if (i % j == 0) {
                    cnt++;
                }
            }
            if (cnt == 2) {
                max = Math.max(max, i);
            }
        }
        return max;


    }

    public static void main(String[] args) {
//        int arr[]={4,8,14,22,36,68};
        int arr[]={14,16,20,22};
        int sum=0;
//        System.out.println(largest(arr,8,14));
    for(int i=0;i<arr.length-1;i++){
          sum=sum+largest(arr,arr[i],arr[i+1]);     }
        System.out.println(sum);
        System.out.println(7+13+19+31+67);


    }
}
