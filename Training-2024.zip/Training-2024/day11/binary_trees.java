import java.util.LinkedList;
import java.util.Queue;

public class binary_trees {
    static class Node{
        int data;
         Node left=null;
         Node right=null;
        Node(int data){
            this.data=data;
            this.left=null;
            this.right=null;
        }
    }
     static Node root=null;
    static int ind=-1;
    public static Node binary_tree(int arr[]){
        ind++;
        if(ind==arr.length || arr[ind]==-1){
            return null;
        }

            Node newnode=new Node(arr[ind]);
            newnode.left=binary_tree(arr);
            newnode.right=binary_tree(arr);
           return newnode;
        }
        public static void preorder(Node root){

        if(root==null){
//            System.out.print("-1"+" ");
        return;}
            preorder(root.left);
            System.out.print(root.data+" ");
            preorder(root.right);
        }
        public static void levelorder(Node ptr){
            Queue<Node> q=new LinkedList<>();
            if(ptr==null){
                return;
            }
            q.add(ptr);
            q.add(null);
            while(!q.isEmpty()){
                Node x=q.remove();
                if(x==null){
                    System.out.println();
                    if(q.isEmpty()){
                        break;
                    }
                    q.add(null);
                }
                else{
                    System.out.print(x.data);
                    if(x.left!=null){
                        q.add(x.left);
                    }
                    if(x.right!=null){
                        q.add(x.right);
                    }
                }
            }
        }



































        public static int cnt_nodes(Node root){
            if(root==null){
//            System.out.print("-1"+" ");
                return 0;}
            return
                    cnt_nodes(root.left)+cnt_nodes(root.right)+1;
        }
        public static int sum(int sum,Node root){
    if(root==null){
        return 0;
    }
    return root.data+sum(sum,root.left)+sum(sum,root.right);

        }
        public static int height(Node root){
        if(root==null){
            return 0;
        }
        return Math.max(height(root.left),height(root.right))+1;


        }
        public static int diameter(Node ptr){

        if(ptr==null){
            return 0;
        }
        int x= diameter(ptr.left);
        int y=diameter(ptr.right);
        int z=height(ptr.left)+height(ptr.right)+1;
        return Math.max(x,Math.max(y,z));

        }









    public static void main(String[] args) {
        binary_trees b=new binary_trees();
        int arr[]={1,2,4,-1,-1,5,-1,-1,3,-1,6,-1,-1};
       Node root= b.binary_tree(arr);
//        System.out.println(root.data);
//        System.out.println(root.left.data+" ");
//Node ptr=root;
//preorder(root);
b.levelorder(root);
        System.out.println(b.cnt_nodes(root));
        System.out.println(b.sum(0,root));
        System.out.println(b.height(root));
        System.out.println(b.diameter(root));


    }
}
