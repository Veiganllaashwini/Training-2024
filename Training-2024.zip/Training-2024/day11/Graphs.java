import java.util.*;
public class Graphs {
    static class Edge {

        int src;
        int dest;

        Edge(int src, int dest) {
            this.src = src;
            this.dest = dest;

        }

    }

    public static void create(ArrayList<Edge> graph[]) {
        for (int i = 0; i < graph.length; i++) {//initially in arr,arraylist is initialised to null..so we have to change it to empty arraylist
            graph[i] = new ArrayList<>();
        }
        graph[0].add(new Edge(0, 1));
        graph[0].add(new Edge(0, 2));
        graph[1].add(new Edge(1, 0));
        graph[1].add(new Edge(1, 3));
        graph[2].add(new Edge(2, 0));
        graph[2].add(new Edge(2, 4));
        graph[3].add(new Edge(3, 1));
        graph[3].add(new Edge(3, 4));
        graph[3].add(new Edge(3, 5));
        graph[4].add(new Edge(4, 2));
        graph[4].add(new Edge(4, 3));
        graph[4].add(new Edge(4, 5));
        graph[5].add(new Edge(4, 3));
        graph[5].add(new Edge(5, 4));
        graph[5].add(new Edge(5, 6));
        graph[6].add(new Edge(6, 5));

    }

//    public static void bfs(ArrayList<Edge> graph[], int v) {
//        Queue<Integer> q = new LinkedList<>();
//        q.add(0);
//        boolean visited[] = new boolean[v];
//        while (!q.isEmpty()) {
//            int curr = q.remove();
//            if (visited[curr] == false) {
//                System.out.println(curr);
//                visited[curr] = true;
//                for (int i = 0; i < graph[curr].size(); i++) {
//                    Edge e = graph[curr].get(i);
//                    q.add(e.dest);
//
//                }
//
//            }
//
//
//        }
//
//
//    }

public static void bfss(ArrayList<Edge> graph[]){
boolean visited[]=new boolean[graph.length];
        Queue<Integer> q=new LinkedList<>();
        q.add(0);
        while(!q.isEmpty()){
            int curr=q.remove();
            if(visited[curr]==false){
                System.out.print(curr+" ");
                visited[curr]=true;
            }
            for(int i=0;i<graph[curr].size();i++){
                Edge e=graph[curr].get(i);
                q.add(e.dest);
            }




        }


}
public static void dfs(ArrayList<Edge> graph[],int curr,boolean visited[]){
    System.out.println(curr);
    visited[curr]=true;
    for(int i=0;i<graph[curr].size();i++){
        Edge e=graph[curr].get(i);
        if(visited[e.dest]==false){
            dfs(graph,e.dest,visited);
        }
    }
}
public static void dfss(ArrayList<Edge> graph[],boolean visited[],int curr,int target,String path){
        if(curr==target){
            System.out.println(path);
            return;
        }

        for(int i=0;i<graph[curr].size();i++){
            Edge e=graph[curr].get(i);
            if(visited[e.dest]==false){
                visited[curr]=true;
                dfss(graph,visited,e.dest,target,path+e.dest);
                visited[curr]=false;
            }
        }
}



        public static void main (String[]args){
            int v = 7;

            Graphs g = new Graphs();
            ArrayList<Edge> graph[] = new ArrayList[v];

            create(graph);
//for(int i=0;i<graph[3].size();i++){//getting neighbour of 3
//    Edge e=graph[3].get(i);
//    System.out.print(e.dest+" ");
//}
//bfs(graph,4);
            boolean visited[] = new boolean[v];
            ArrayList<Integer> ds=new ArrayList<>();
//            dfs(graph, 0, visited);
//            bfss(graph);
            String path="0";
            dfss(graph,visited,0,5,path);

//            System.out.println(ds);
        }
}
