import java.util.HashMap;
import java.util.*;

public class bstt {

    static class Node{
        int data;
        Node left;
        Node right;
        Node(int data){
            this.data=data;
            this.right=null;
            this.left=null;
        }
    }
    static Node root=null;

    public static Node insert(Node ptr,int val)
    {
        if(ptr==null){
            ptr=new Node(val);
            return ptr;
        }
        if(val<ptr.data){
            ptr.left=insert(ptr.left,val);
        }
        else if(val>ptr.data){
            ptr.right=insert(ptr.right,val);
        }
        return ptr;


    }
    public static int nodes(Node ptr) {
        if (ptr == null)
            return 0;
        else {
            int left = nodes(ptr.left);
            int right = nodes(ptr.right);
//            if (ptr.data % 2 == 1) {
//                return ptr.data + left + right;
//            }
//            else return left+right;
            return ptr.data+left+right;
        }
    }

    public static int left_sum(Node ptr){
        if(ptr==null)
            return 0;
        int x=nodes(ptr.left);
        return x;



    }
    public static void topview(Node root, int cnt, HashMap<Integer,Integer> ds){

        if(root==null)
            return;
         if( !ds.containsKey(cnt)){
            ds.put(cnt,root.data);}
//            System.out.print(root.data+"  ");}
        else if(ds.containsKey(cnt) && cnt<0 && root.data>ds.get(cnt)){
            ds.put(cnt,root.data);
//            System.out.print(root.data+" ");
        }
        topview(root.left,cnt+1,ds);
        topview(root.right,cnt-1,ds);
    }
    public static void leftview(Node root, int cnt, HashSet<Integer> ds){

        if(root==null)
            return;
        if(!ds.contains(cnt)){
            ds.add(cnt);
        System.out.println(root.data+":  "+cnt);}
        leftview(root.left,cnt+1,ds);
        leftview(root.right,cnt+1,ds);

    }
    public static void rightview(Node root, int cnt, HashSet<Integer> ds){

        if(root==null)
            return;
        if(!ds.contains(cnt)){
            ds.add(cnt);
            System.out.println(root.data+":  "+cnt);}
        rightview(root.right,cnt+1,ds);
        rightview(root.left,cnt+1,ds);

    }

        public static int cnt (Node ptr){

            if (ptr == null) {
                return 0;
            }
            int left = cnt(ptr.left);
            int right = cnt(ptr.right);
            return 1 + left + right;
        }
    public static int  greater (Node ptr) {

        if (ptr == null) {
            return 0;
        }
        int left = greater(ptr.left);
        int right = greater(ptr.right);
        if (ptr.data > 1) {
            return 1 + left + right;
        } else {
            return left + right;
        }
    }
    public static int max(Node ptr){

        if(ptr==null){
            return Integer.MIN_VALUE;
//            return 0;if you do this..you will get wrong output for negative numbers
        }
        int left=max(ptr.left);
        int right=max(ptr.right);
        return Math.max(ptr.data,Math.max(left,right));

    }
    public static int no_leaf_nodes(Node ptr,int cnt){
        if(ptr==null)
            return 0;
  if(ptr.left==null && ptr.right==null){
    return 1;
}
int left=no_leaf_nodes(ptr.left,cnt);
int right=no_leaf_nodes(ptr.right,cnt);
return left+right;

    }
    public static int height(Node ptr,int cnt){
        if(ptr==null){
            return 0;
        }
        int left=height(ptr.left,cnt);
        int right=height(ptr.right,cnt);
        return Math.max(left,right)+1;

    }

    public static void main(String[] args) {
        bstt b=new bstt();
//        root=b.insert(root,10);
//        root=b.insert(root,5);
//        root=b.insert(root,15);
//        root=b.insert(root,2);
//        root=b.insert(root,7);
//        root=b.insert(root,11);
//        root=b.insert(root,20);
//        root=b.insert(root,4);
//        root=b.insert(root,3);



                root=b.insert(root,10);
        root=b.insert(root,5);
        root=b.insert(root,15);
        root=b.insert(root,2);
        root=b.insert(root,7);
        root=b.insert(root,11);
        root=b.insert(root,20);
        root=b.insert(root,4);
        root=b.insert(root,3);
        root=b.insert(root,12);
        root=b.insert(root,13);
        root=b.insert(root,14);

//        root=b.insert(root,5);root=b.insert(root,453);
//
//        root=b.insert(root,0);
//        System.out.println(root.data);
//        System.out.println(root.right.data);
//        System.out.println(nodes(root));
//        System.out.println(cnt(root));
//        System.out.println(left_sum(root));
//        System.out.println(max(root));
//        System.out.println(no_leaf_nodes(root,0));
//        System.out.println(height(root,0));
        HashSet<Integer> hm=new HashSet<>();
        HashMap<Integer,Integer> hs=new HashMap<>();
        rightview(root,0,hm);
        topview(root,0,hs);
        System.out.println(hs);


    }
}
