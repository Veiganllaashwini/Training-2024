import java.util.*;
public class training {

    public static ArrayList<Integer> solve(int i,int j,int esum,int[] arr1,int[] arr2,ArrayList<Integer> ds){
        if(j>=arr2.length){
            j=0;
            i++;

        }
        if(i>=arr1.length) {
//            System.out.println(ds);
            return ds;
        }
        if(arr1[i]%2==0){
            esum=arr1[i];
            if(arr2[j]%2==1){
                ds.add(esum+arr2[j]);
                return solve(i,j+1,esum,arr1,arr2,ds);
            }
            else{
                return solve(i,j+1,esum,arr1,arr2,ds);
            }
        }
        else{
            i++;
            return solve(i,j,esum,arr1,arr2, ds);
        }


    }

    public static void main(String[] args) {
        int arr1[]={6,3,2,9,4,7};
        int arr2[]={8,7,5,3,6,9};
        int i=0,j=0;
        int esum=0;
        ArrayList<Integer> dss=new ArrayList<>();
        int osum=0;
//        while(i<arr1.length) {
//            j=0;
//            if (arr1[i] % 2 == 0) {
//                esum = arr1[i];
//            } else {
//                while (j < arr2.length) {
//                    if (arr2[j] % 2 == 1) {
//                        dss.add(esum + arr2[j]);
//                    }
//                    j++;
//
//
//                }
//
//
//            }
//            i++;
//        }
//        System.out.println(dss);
        ArrayList<Integer> ds=new ArrayList<>();

        System.out.println(solve(0,0,0,arr1,arr2,ds));
//        System.out.println(ans);

//        System.out.println(ds);
    }
}
