public class day12_2 {
    public static int solve(int i,int j,int[][]x) {

        if (i < 0 || j < 0 || i == x.length || j == x.length || x[i][j]==0 || x[i][j]==2) {
            return 0;
        }
            int t=1;
              x[i][j]=2;
              t=t+solve(i - 1, j, x);
            t=t+solve(i + 1, j, x);
             t=t+solve(i, j - 1, x);
             t=t+solve(i, j + 1, x);
             return t;

        }



        public static void main (String[]args){
            int x[][] = {{0, 1, 0, 0, 1}, {1, 0, 0, 1, 1}, {0, 0, 0, 0, 0}, {1, 0, 0, 0, 0}, {1, 0, 0, 0, 1}};
            int flag = 0;
            int cnt = 0;
            for (int i = 0; i < x.length; i++) {
                for (int j = 0; j < x[0].length; j++) {
                    if (x[i][j] == 1) {
                        System.out.println(solve(i, j, x));
                        cnt++;
                    }
                }
            }
            System.out.println(cnt);

        }
    }
