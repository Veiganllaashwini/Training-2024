import java.util.HashMap;
//to check if a given string contains all 26 small alphabets...given string is combination of  all digits,special characters,numbers and UpperCase

public class day8_2 {
    public static void main(String[] args) {
        int flag=0;
        String s = "the 4quick br$%^own foENDx j45umps o.ver the lazy dog";
        HashMap<Character, Integer> hm = new HashMap<>();
        for (int i = 0; i < s.length(); i++) {
            int x=(int)s.charAt(i);
            hm.put(s.charAt(i), 1);
            if (s.charAt(i) == ' ') {

            }
            if(x>=65 && x<90){

            }
            if(x>=33 && x<=64)
            {

            }
        }
        for(int i=97;i<=122;i++){
            if ((hm.get((char)i))==null){
                flag=1;
                break;
            }
//            if (x == 0) {
//                System.out.println("no");
//                break;
//            }
        }
        if(flag==1)
            System.out.println("no");
        else
            System.out.println("yes");

    }
}
