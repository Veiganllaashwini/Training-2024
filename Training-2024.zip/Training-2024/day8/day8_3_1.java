import java.util.ArrayList;
import java.util.HashMap;
//getting error

public class day8_3_1 {
    public static void main(String[] args) {
        String s="abfgresagtyuiofds";
        int n=s.length();
        HashMap<Character,Integer> hm=new HashMap<>();
        for(int i=0;i<n;i++){
            char x=s.charAt(i);
            if(hm.containsKey(x)){

            }
            else{
                hm.put(x,i);
            }

        }
        ArrayList<Character> ds=new ArrayList<>();
        int i=0;
        int max=0;
        int cnt=0;

        while(i<n){
            char x=s.charAt(i);
            if(ds.contains(x)){
                max=Math.max(ds.size(),max);
                ds.clear();
                i=hm.get(x)+1;
                System.out.println("i"+i);
            }
            else{
                ds.add(x);
                i++;
            }
        }
        System.out.println(cnt);
    }
}
