public class day8_4 {

    public static void solve(int[][] arr,int i,int j){
        if(i<0 || j<0  || i>=arr.length ||j>=arr[0].length){
            return;
        }
        if(arr[i][j]==1){
            arr[i][j]=-1;
            solve(arr,i,j-1);
            solve(arr,i-1,j);
            solve(arr,i,j+1);
            solve(arr,i+1,j);
        }
        else if(arr[i][j]==0){
            return;}
    }

    public static void main(String[] args) {
        int cnt=0;
        int arr[][]={{0,1,1,1,0,1},{0,1,0,1,0,0},{1,0,1,1,0,0,},{0,0,0,1,1,1},{1,1,0,0,0,1},{1,1,1,0,1,0}};
        solve(arr,4,5);
        for(int i=0;i<arr.length;i++){
            for(int j=0;j<arr[0].length;j++){
                if(arr[i][j]==1)
                    cnt++;
            }
        }
        System.out.println(cnt);
    }
}
