import java.util.*;
public class day8_3 {

    public static void main(String[] args) {
        String s="abfgresagtyuiofde";

        ArrayList<Character> ds=new ArrayList<>();
        int n=s.length();
        int i=0;
        int max=0;
        int cnt=0;
        int j=0;
        while(i<n && j<n){
            char x=s.charAt(i);
            if(ds.contains(x)){
                ++j;
                i=j;
                max=Math.max(ds.size(),max);
                ds.clear();
                while(s.charAt(j)=='x'){
                    j++;
                }
                i=j;

            }
            else{

                ds.add(x);
                i++;
            }
        }
        System.out.println(max);
//        while(i<n && j<n){
//            char x=s.charAt(i);
//            if(ds.contains(x)){
//                System.out.print(ds);
//                System.out.println();
//                ++j;
//                i=j;
//                System.out.println("cnt"+cnt);
//                max=Math.max(cnt,max);
////                System.out.println(max);
//                cnt=0;
//                ds.clear();
//            }
//            else{
//                ds.add(x);
//                cnt++;
//                i++;
//            }
//
//
//        }
//        System.out.println(max);

    }
}
