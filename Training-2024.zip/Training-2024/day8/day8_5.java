public class day8_5 {
    public static void solve(char[][] arr,int i,int j,char[] s,int k) {


        if (i < 0 || j < 0 || i >= arr.length || j >= arr[0].length || arr[i][j] != s[k]) {
            return;
        }
        if (k >= s.length) {
            return;
        }
        if (arr[i][j] == s[k]) {
            arr[i][j] = '%';
            k++;
            return;
        }
            solve(arr, i, j - 1, s, k );
        System.out.println(k);
            solve(arr, i - 1, j, s, k );
            solve(arr, i, j + 1, s, k );
            solve(arr, i + 1, j, s, k );


    }
    public static void main(String[] args) {
   char c[][]={{'t','u','e','d'},{'f','w','o','w'},{'r','o','e','r'},{'d','r','u','i'}};
   int x=c.length;
   int y=c[0].length;
   char s[]={'w','o','r','d'};
        solve(c,x-1,y-1,s,0);
        for(int i=0;i<s.length;i++){
            System.out.print(s[i]+" ");
        }
        System.out.println(s);
        for(int i=0;i<c.length;i++){
            for(int j=0;j<c[0].length;j++){
                System.out.print(c[i][j]+" ");
            }
        }

    }
}
