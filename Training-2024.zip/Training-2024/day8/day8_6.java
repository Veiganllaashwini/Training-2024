import java.util.*;
class day8_6 {

    public static void solve(int ind,ArrayList<Integer> ds,int[] arr,int s,int sum,ArrayList<List<Integer>> ans){
        if(ind==arr.length){
            if(s==sum){
                ans.add(new ArrayList<>(ds));
                System.out.println(ans);
            }
            return;
        }
        ds.add(arr[ind]);
        solve( ind+1, ds, arr, s+arr[ind], sum,ans);
        ds.remove(ds.size()-1);
        solve( ind+1, ds, arr, s, sum,ans);
    }

    public static void main(String[] args) {
        int costs[]={7,3,3,6,6,6,10,5,9,2};
        Arrays.sort(costs);
        int coins=56;
        if (costs == null || costs.length == 0 || coins <= 0) {
            System.out.println(0);
        }
        ArrayList<List<Integer>> ans=new ArrayList<>();
        ArrayList<Integer> ds=new ArrayList<>();
        solve(0,ds,costs,0,coins,ans);
        int maxSize=0;
        for (List dss : ans) {
            if (dss.size() > maxSize) {
                maxSize = dss.size();
            }
        }
        System.out.println(maxSize);
    }

}