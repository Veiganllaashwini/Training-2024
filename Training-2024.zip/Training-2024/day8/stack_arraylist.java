import java.util.*;

public class stack_arraylist {

    static class stack{

        ArrayList<Integer> arr=new ArrayList<>();
        public boolean isEmpty(){
            return arr.size()==0;
        }
        public void push(int data){

                arr.add(data);
        }
        public int pop(){

            if(isEmpty())
                return -1;
            else{
                int top=arr.get(arr.size()-1);
                arr.remove(arr.size()-1);
                return top;
            }
        }
        public int peek(){
            if(isEmpty())
                return -1;

            return arr.get(arr.size()-1);
        }

    }
    public static void main(String[] args) {
        stack s=new stack();
        s.push(1);
        s.push(2);
        s.push(3);
        System.out.println(s.isEmpty());
        System.out.println(s.pop());
        System.out.println(s.peek());
    }
}
