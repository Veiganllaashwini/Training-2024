import java.util.*;
public class tar_sum {
    public static void solve(int ind,int target,ArrayList<Integer> ds,int[] arr){
        if(ind==arr.length){
            if(target==0){
                System.out.println(ds);
            }
            return;
        }
        else{
            if(arr[ind]<=target) {
                ds.add(arr[ind]);
                solve(ind + 1,  target - arr[ind], ds, arr);
                        ds.remove(ds.size()-1);
            }
            solve(ind+1,target,ds,arr);

        }

    }
    public static void main(String[] args) {
        int arr[]={1,2,3,4,5};
        ArrayList<Integer> ds=new ArrayList<>();
        int target=4;
        solve(0,target,ds,arr);
    }
}
