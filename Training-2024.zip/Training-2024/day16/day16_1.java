public class day16_1 {
    public static void main(String[] args) {
        int[] arr={3,4,5,10,4,3};
        int n=arr.length;
        int cnt1=0;
        int cnt2=0;
        int last=arr[n-1];
        int first=arr[0];
        cnt1++;
        cnt2++;
        for(int i=1;i<n;i++){
            if(arr[i]>first){
                cnt1++;
                first=arr[i];
            }
        }
        for(int j=n-2;j>=0;j--){
            if(arr[j]>last){
                cnt2++;
                last=arr[j];
            }
        }
        System.out.println(cnt1);
        System.out.println(cnt2);
    }
}
