import java.util.*;
public class day16_4 {//make largest even number from given digits
    public static void main(String[] args) {
        int n=521863;
        int rem;
        int cnt=0;
        ArrayList<Integer> ds=new ArrayList<>();
        while(n!=0){
            rem=n%10;
            ds.add(rem);
            cnt++;
            n=n/10;
        }
        System.out.println(cnt);
        Collections.sort(ds);
        System.out.println(ds);
        int arr[]=new int[cnt];
       for(int i=0;i<cnt;i++){
           arr[i]=ds.get(i);
       }
       int sum=0;
       for(int i=cnt-1;i>=0;i--){
           sum=(sum)+arr[i]*(int)Math.pow(10,i);
       }
       ArrayList<Integer> even=new ArrayList<>();
        ArrayList<Integer> odd=new ArrayList<>();
        System.out.println("sum:"+sum);
       for(int i=0;i<arr.length;i++){
           if(arr[i]%2==0){
               even.add(arr[i]);
           }
           else{
               odd.add(arr[i]);
           }
       }
        System.out.println(even);
        System.out.println(odd);int k=cnt-1;
        int summ=0;
        for(int j=even.size()-1;j>=1;j--){
            summ=summ+(even.get(j))*(int)Math.pow(10,k);
            k--;
        }
        for(int j=odd.size()-1;j>=0;j--){
            summ=summ+(odd.get(j))*(int)Math.pow(10,k);
            k--;
        }
        System.out.println(summ+even.get(0));
    }
}
