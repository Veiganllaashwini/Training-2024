import java.util.ArrayList;

public class day16_2 {
    public static void solve(int ind,int target,ArrayList<Integer> ds,int[] arr){
        if(ind==arr.length){
            if(target==0){
                System.out.println(ds);
            }
            return;
        }
        else{
            if(arr[ind]<=target) {
                ds.add(arr[ind]);
                solve(ind,  target - arr[ind], ds, arr);
                ds.remove(ds.size()-1);
            }

            solve(ind+1,target,ds,arr);

        }

    }




    public static void main(String[] args) {
        int[] arr={2,3,5,6};
        int n=20;
        ArrayList<Integer> ds=new ArrayList<>();
        solve(0,n,ds,arr);
    }
}
