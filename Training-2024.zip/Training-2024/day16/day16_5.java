
import java.util.*;
public class day16_5 {
    public static boolean reverse(StringBuilder sc) {
        StringBuilder s = new StringBuilder(sc);
//        System.out.println("rev: "+sc.reverse());
//        System.out.println("s: "+s);
        StringBuilder x=sc.reverse();
        System.out.println("x:  "+x);
        System.out.println("s:  "+s);
        System.out.println("check"+(x==s));
        if (x==s){
            System.out.println("yess");

            return true;}
        return false;
    }

    public static void main(String[] args) {
        String s = "abdbsdabca";
        int n = s.length();
        int maxcnt = -1;
        int cnt = 0;
        StringBuilder sc = new StringBuilder();
        for (int i = 0; i < n; i++) {
            StringBuilder x = sc.append(s.charAt(i));
            System.out.println(x);
            if (reverse(x)) {
                cnt++;
                maxcnt = Math.max(cnt, maxcnt);

            }
//            System.out.println(sc);
//                StringBuilder ans=sc.reverse();
//            System.out.println(ans);
//                 if(x.equals(ans)){
//                     cnt++;
//            }
//                 if(cnt>maxcnt){
//                     cnt=maxcnt;
//                 }
//        }
            System.out.println(maxcnt);
        }
    }
}
