import java.util.*;
public class day3_1 {
    public static void main(String[] args) {
        String s;
        Scanner sc = new Scanner(System.in);
        s = sc.next();
        StringBuilder str = new StringBuilder(s);

        int n = sc.nextInt();
        n=n%26;
        for (int i = 0; i < s.length(); i++) {
            char x = s.charAt(i);
            if (((int) x - n) < 97) {
                System.out.print(((char)((int) x + (26 - n))));
            } else {
                System.out.print((char)((int) x - n));
            }
//            System.out.println(s);
//            System.out.println(str);

//        int n=3;
//        int x=97;
//        int ans=0;
//        int y=122;
//        char z='a';
//        if(((int)z-3)<=97){
//            ans=(int)z+(25-n);
//        }
//        System.out.println(ans);
//        System.out.println((int)z);
//        System.out.println((char)((int)'a'-3));

        }
    }
}
