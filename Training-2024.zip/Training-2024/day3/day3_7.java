//public class day3_7 {
//    public static void main(String[] args) {
//        int n=4;
//        for(int i=0;i<7;i++){
//            System.out.println();
//            int num=1;
//            for(int j=0;j<7;j++){
//
//                if(i==0 || i==6 || j==0|| j==6){
//                    System.out.print(num+" ");
//                }
//                else if(i>0){
//                    System.out.print(num+1+" ");
//                }
//                num++;
//        int num=1;
//        for(int i=0;i<7;i++){
//            System.out.println();
//            for(int j=0;j<7;j++){
//
//                if(i==0 || i==6 || j==0 || j==6){
//                    System.out.print(num+" ");
//                }
//
//                else if(i>0 && j>0){
//
//                }
//                else{
//                    System.out.print("  ");
//                }
//
//            }
//        }
//    }
//}
//4
//
//1 1 1 1 1 1 1
//1 2 2 2 2 2 1
//1 2 3 3 3 2 1
//1 2 3 4 3 2 1
//1 2 3 3 3 2 1
//1 2 2 2 2 2 1
//1 1 1 1 1 1 1