public class day3_2 {
    public static void main(String[] args) {
        String s="abcdehijk";
//        System.out.println(s.length());
        int cnt=0;
        int max_cnt=Integer.MIN_VALUE;
        int i=0;
     while(i<s.length()-1){
            cnt = 1;
            while (((int) s.charAt(i)) - ((int) s.charAt(i+1)) == -1) {
                cnt++;
//                System.out.print(cnt+" ");
                i++;
                if(i==s.length()-1){
                    break;
                }
            }
//         System.out.println("cnt"+cnt);
            i++;
            max_cnt=Math.max(cnt,max_cnt);
//         System.out.println("max_cnt"+max_cnt);

        }

        System.out.println(max_cnt);
    }
}
