import java.util.*;
public class day3_3 {

    public static void main(String[] args) {
        String s = "hhprhp";
        List<List<String>> exampleLists = Arrays.asList(
                Arrays.asList("Joseph"), Arrays.asList("John"), Arrays.asList("Joker"));


        int j = 0;
        for (int i = 0; i < s.length(); i++) {
//        System.out.println(exampleLists.get(2));
            if ((exampleLists.get(0)).contains(s.charAt(i))) {
                System.out.println("yes");
                break;
            }
            else{
                System.out.println("noo");
            }
//        for(List list : exampleLists)

       /* for(Object i : list)

        {
            System.out.println(i);

}*/
//        System.out.println(exampleLists.get(1).get(0));
//
//            System.out.print( i+ ", ");

            }
        }


//    List<List<String>> str=new ArrayList<>();
//      List<String> ss=new ArrayList<>();
//      ss.add("hello");
//      ss.add("hiii");
//      ss.add("pqrs");
//      ss.add("rtyu");
//      str.add(new ArrayList(ss));
//        System.out.println(str);
//        System.out.println(ss.get(0));

//      String a[][]={{"hello"},{"hiii"},{"pqrs"},{"rtyu"}};
//        System.out.println(a.length);
//        System.out.println(a[0].length);
//      for(int i=0;i<a.length;i++){
//          for(int j=0;j<a[0].length;j++){
//              System.out.println(a[i][j]);
//          }
//      }


    }
