import java.util.*;
public class day3_4 {
   public static int reversed(int n,int sum){
if(n==0){
    return sum;
}
sum=(sum*10)+n%10;
n=n/10;
return reversed(n,sum);
   }
    public static void main(String[] args) {
       Scanner sc=new Scanner(System.in);
       int n=sc.nextInt();
       int x=reversed(n,0);
         if(x==n){
            System.out.println("Yes,a palindrome");
        }
        else{
            System.out.println("Not a palindrome");
        }
//        int sum=0;
//        while(n!=0){
//            sum=(sum*10)+(n%10);
//            n=n/10;
//        }
//        System.out.println(sum,0);
    }
}
