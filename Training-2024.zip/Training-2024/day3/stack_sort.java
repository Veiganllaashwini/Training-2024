import java.util.*;

public class stack_sort {
    public static void pushAtbottom(int data,Stack<Integer> s){
      if(s.isEmpty()){
          s.push(data);
      return;}
      int top=s.pop();
      pushAtbottom(data,s);
      s.push(top);

//        s.push(data);
//        s.push(top);
    }

    public static void reverse(Stack<Integer> s){
        if(s.isEmpty())
            return;
        int top=s.pop();
        reverse(s);
        pushAtbottom(top,s);


    }


    public static void main(String[] args) {
        Stack<Integer> s = new Stack<>();
        s.push(1);
        s.push(2);
        s.push(9);
        s.push(103);
        s.push(3);
        Stack<Integer> temp = new Stack<>();
        if (temp.isEmpty()) {
            temp.push(s.pop());
        }
        while (!s.isEmpty()) {
            int top = s.pop();
            while ( !temp.isEmpty() && top < temp.peek()) {
                s.push(temp.pop());
            }
            temp.push(top);

        }


//        pushAtbottom(4,s);
//        reverse(s);
        while (!temp.isEmpty()) {
            System.out.println(temp.peek());
            temp.pop();

        }
    }
    }

