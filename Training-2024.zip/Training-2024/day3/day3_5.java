public class day3_5 {
    public static void main(String[] args) {
        int[] arr={15,3,2,7,8,4};
//        int buyy=Integer.MAX_VALUE;
//        int buy=0;
//        int sell=0;
//        int selll=Integer.MIN_VALUE;
//            for(int i=0;i<arr.length-1;i++){
//                if(arr[i]<arr[i+1]){
//
//                }
//                if(arr[i]<arr[i+1]){
//                    buy=arr[i];
//                sell=arr[i+1];
//            }
//            buyy=Math.min(buyy,buy);
//            selll=Math.min(selll,sell);
//
//
//        }
        int pr=0;
        int prof=-1;
       int buy=arr[0];
       int p=0;
       for(int i=1;i<arr.length;i++){
           if(arr[i]<buy){
               buy=arr[i];
           }
           else if(arr[i]>buy){
               pr=(arr[i]-buy);
           }
           prof=Math.max(pr,prof);
       }
        System.out.println(prof);

        }

    }

