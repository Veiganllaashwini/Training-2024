import java.util.*;
public class day13_2 {
    public static void solve(int ind,String s,String ans){
        if(ind==s.length()){
            System.out.println(ans);
            return;
        }
        ans=ans+s.charAt(ind);
        solve(ind+1,s,ans);


    }

    public static void main(String[] args) {
        String s1="abcd";
        ArrayList<Character> ds=new ArrayList<>();
        String ans=" ";
        solve(0,s1,ans);
    }
}
