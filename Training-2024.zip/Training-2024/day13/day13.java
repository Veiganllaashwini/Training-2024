public class day13{
   public static boolean palindrome(int num,int n,int sum){
       if(n==0)
           return sum==num;
        sum=(sum*10)+(n%10);
        return palindrome(num,n/10,sum);

    }
    public static void main(String[] args) {
        int n=56472;
        String s="5462";
        StringBuilder sc=new StringBuilder(s);
//        System.out.println(s.concat("2"));
//        System.out.println(sc.reverse());
        int sum=0;
        if(palindrome(n,n,0)){
            System.out.println(n);
        }
        else{
//            n=n+1;
//            while(palindrome(n,n,0)!=true){
//                n=n+1;
//            }
//            System.out.println(n);


        }

        }
//        while(n!=0){
//            sum=(sum*10)+(n%10);
//            n=n/10;
//
//        }
//        System.out.println(sum);
    }

