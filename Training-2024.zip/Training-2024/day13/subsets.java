import java.util.*;

public class subsets {
    public static void solve(int ind,ArrayList<String> ds,HashSet<List<String>> ans,String s){

        if(ind==s.length()){
            ans.add(new ArrayList(ds));
            return;
        }
        ds.add(String.valueOf(s.charAt(ind)));
        solve(ind+1,ds,ans,s);
        ds.remove(ds.size()-1);
        solve(ind+1,ds,ans,s);


    }
    public static void main(String[] args) {
        String s="adebc";
        ArrayList<String> ds=new ArrayList<>();
        HashSet<List<String>> ans=new HashSet<>();
//        int arr[]={1,2,3};
        solve(0,ds,ans,s);
        for(List ele: ans){
            System.out.println(ele);
        }
        System.out.println(ans.size());


    }
}
