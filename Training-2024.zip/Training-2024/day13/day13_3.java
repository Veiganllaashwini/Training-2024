public class day13_3 {
    public static void main(String[] args) {
//        int x=7262;
//        System.out.print(x/3600+"hrs ");
////        System.out.println(x%3600);
//        System.out.print((x%3600)/60+"min ");
//        System.out.println((x%3600)%60+"sec ");

        int x=65476;
        System.out.println("years"+x/360);
        System.out.println(x%360);
        System.out.println(x%12);
        System.out.println((x%12)/6);
        System.out.println();
        System.out.println((181*360)+(120));

    }
}
