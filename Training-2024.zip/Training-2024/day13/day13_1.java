//import java.util.HashMap;
//import java.util.*;
//public class day13_1 {
//    public static void main(String[] args) {
//        int[] start = {1, 2, 4, 6, 5, 7};
//        int n = start.length;
//        int end[] = {3, 5, 6, 7, 8, 9};
//        int a[] = {5, 6, 5, 4, 11, 2};
//        int sum = 0;
//        int b[]={5,6,5,4,11,2};
////        int i = 0;
////        int j = 0;
////        int prev = -1;
////        int cnt = 0;
////        int k=0;
////        while (cnt < 6) {
////            while (i < n && j < n) {
////                if (start[i] >= prev && start[i] < end[j]) {
////                    sum = sum + time[i];
////                    prev = end[j];
////                }
////                i++;
////                j++;
////            }
////            System.out.println(sum);
////            k++;
////            cnt++;
////            i = k;
////            j = k;
////            sum=0;
////            prev=-1;
////        }
//for(int i=0;i<n;i++){
//for(int j=1;j<=i;j++){
//    if(end[i]<=start[j]){
//        if(a[i]+b[j]>b[i]){
//            b[i]=a[i]+b[j];
//        }
//
//    }
//
//    }
//
//
//
//}
//    }
//}
//
