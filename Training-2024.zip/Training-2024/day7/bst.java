//public class bst {
//
//    static class Node{
//    int data;
//    Node left=null;
//    Node right=null;
//    Node(int data){
//        this.data=data;
//        this.left=null;
//        this.right=null;
//    }}
//    static Node root=null;
//
//    public static Node insert(Node ptr,int val){
//        if(ptr==null){
//            ptr=new Node(val);
//            return ptr;
//    }
//        if(val<ptr.data){
//            ptr.left=insert(ptr.left,val);
//
//        }
//        else if(val>ptr.data){
//            ptr.right=insert(ptr.right,val);
//        }
//        return ptr;
//
//
//    }
//    public static void inorder(Node root){
//        if(root==null){
//            return;
//        }
//        inorder(root.left);
//        System.out.println(root.data);
//        inorder(root.right);
//
//
//
//    }
//    public static boolean search(Node ptr,int val){
//        if(ptr==null){
//            return false;
//        }
//        if(ptr.data==val){
//            return true;
//        }
//         if(val<ptr.data){
//            return search(ptr.left,val);
//        }
//        else if(val>ptr.data){
//            return search(ptr.right,val);
//        }
//
//
//
//    }
//
//
//    public static void main(String[] args) {
//        bst b=new bst();
//        root=b.insert(root,20);
//        root=b.insert(root,30);
//        root=b.insert(root,15);
//        System.out.println(root.data);
//        b.inorder(root);
//        System.out.println(b.search(root,100));
//
//
//
//    }
//}
