import java.util.*;
public class doubly_linkedlist {
    static class dll{
        static class Node{

            int data;
            Node prev=null;
            Node next=null;
            Node(int data){

                this.data=data;
                this.prev=null;
                this.next=null;
            }
        }
         static Node head=null;
               static  Node tail=null;
      public static void add_back(int data){
          Node newnode=new Node(data);
          if(head==null && tail==null){

              tail=newnode;
              head=newnode;
              head.prev=null;
              tail.next=null;
              return;
//              tail=newnode;
//              head=newnode;
//              newnode.prev=tail;
//              tail=tail.next;
//              return;
          }
          tail.next=newnode;
          newnode.prev=tail;
          tail=tail.next;

      }
      public static void add_beg(int data){

          Node newnode=new Node(data);
          if(head==null && tail==null){
head=newnode;
tail=newnode;
head.prev=null;
tail.next=null;
return;
          }
          newnode.next=head;
          newnode.prev=null;
          head.prev=newnode;
          head=newnode;

      }

      public static void print(){
          Node ptr=head;
          while(ptr!=null){
              System.out.print(ptr.data+" ");
              ptr=ptr.next;
          }
          System.out.println();

      }
      public static void perform(){

          Node slow=head;
          Node ptr=head;
          Node fast=head;
          while(fast!=null && fast.next!=null){
              slow=slow.next;
              fast=fast.next.next;
          }
        /*  Node x=slow;
          while(ptr.next!=x.next){
              int temp=ptr.data;
              ptr.data=slow.data;
              slow.data=temp;
              ptr=ptr.next;
              slow=slow.next;

          }*/
          tail.next=head;
          head.prev=tail;
          Node t1=slow.prev;
          t1.next=null;
          slow.prev=null;head=slow;
          tail=t1;





//          while(slow!=null){
//              System.out.print(slow.data+" ");
//              slow=slow.next;
//          }
//          while(ptr!=x){
//
//              System.out.print(ptr.data+" ");
//              ptr=ptr.next;
//          }
      }
      public static Node del_beg(){
          if(head==null && tail==null)
              return null;
          head=head.next;
          head.prev=null;
          return head;
      }
      public static void del_end(){

          if(head==null && tail==null)
              return;
          Node ptr=head;
          while(ptr.next!=tail){
             ptr.next=null;
             tail=ptr;
          }
      }
      public static void length() {
          Node ptr = head;
          Node temp = tail;
          while (ptr != temp && ptr != temp.next) {
              ptr = ptr.next;
              temp = temp.prev;
          }
          if (ptr == temp.next) {
              System.out.println("even length");
          } else {
              System.out.println("odd length");

          }
      }

      public static boolean palindrome(){
          if(head==tail){
              return true;
          }
          Node ptr=head;
          Node temp=tail;
          while(ptr!=temp.next){
              if(ptr==temp){
                  return true;
              }
              if(ptr.data !=temp.data){
                  return false;
              }
              ptr=ptr.next;
              temp=temp.prev;
          }
          if(ptr.data==temp.data){
              return true;
          }

          return false;
      }
      public static int answer(Node  ptr,int esum,int oddsum){
          if(ptr==null){
              return Math.abs(esum-oddsum);
          }
          else if(ptr.data%2==0){
              esum=esum+ptr.data;
          }
          else{
              oddsum=oddsum+ptr.data;
          }
         ptr=ptr.next;
          return answer(ptr,esum,oddsum);
      }

      public static boolean isPrime(int n,int i,int cnt){
          if(i>n){
              if(cnt==2)
                  return true;
              return false;
          }
          else{
              if(n%i==0){
                  cnt++;
              }
              return isPrime(n,i+1,cnt);
          }
      }

      public static int cnt(Node ptr,int cnt){
          if(ptr==null){
              return cnt;
          }
          if(isPrime(ptr.data,1,0)){
              cnt++;
          }
          ptr=ptr.next;
          return cnt(ptr,cnt);


      }
//      public static int valid(Stack<Character> s) {
//          Node ptr = head;
//          int cnt=1;
//          while (ptr != null) {
//              char c = ptr.data;
//              if (c == '(' || c == '{' || c == '[') {
//                  s.push(c);
//              } else if (c == ')' || c == '}' || c == ']') {
//                  if (s.isEmpty()) {
//                      return 0;
//                  }
//                  char ch = s.peek();
//                  if ((c == ')' && ch == '(') || ((c == '}') && (ch == '{')) || ((c == ']') && (ch == '['))) {
//                      s.pop();
//                  } else {
//                      return cnt;
//                  }
//              }
//              ptr = ptr.next;
//              cnt++;
//          }
//          if (s.isEmpty()) {
//              return -1;
//          } else {
//              return cnt;
//          }
//      }
//      public static void reverse_pairs(){
//
//          Node t3=null;
//          Node t=head;
//          Node t1=head.next;
//
//          while(){
//              t.next=t1.next;
//              t1.next=t;
//              t1.prev=t3;
//              t.prev=t1;
//              t3.next=t1;
//              swap t and t1
//                      t3=t1
//
//
//
//          }
//
//      }
//      public static boolean linear(int n){
//          Node ptr=head;
//        Node temp=tail;
//        while(ptr!=temp && ptr!=temp.next){
//            if(ptr.data==n || temp.data==n){
//                return true;
//            }
//            ptr=ptr.next;
//            temp=temp.prev;
//        }
//        if(ptr.data==n)
//            return true;
//        return false;
//      }
    }
    public static void main(String[] args) {
        dll l=new dll();
//        l.add_back('[');
//        l.add_back('(');
//        l.add_back(')');
//        l.add_back('{');
//        l.add_back('}');
//        l.add_back('{');
//        l.add_back('(');
//        l.add_back(')');
//        l.add_back('}');
//        l.add_back(']');
//        l.add_back(')');
        l.add_back(1);
        l.add_back(2);
        l.add_back(3);
        l.add_back(4);
        l.add_back(5);
        l.add_back(6);
        l.add_back(7);
        l.add_back(8);
        l.add_back(9);
        l.add_back(11);
//        l.add_back(6);
//        l.add_back(4);
//        l.add_back(8);


//        l.add_back('[');
//        l.add_back('{');
//        l.add_back('(');
//        l.add_back(')');
//        l.add_back(']');
//        l.add_back(']');
        l.print();
//        Stack<Character> s=new Stack<>();
//        System.out.println(l.answer(l.head,0,0));
        System.out.println(l.cnt(l.head,0));
//        System.out.println(l.valid(s));
//        l.reverse_pairs();
//        l.perform();
//        l.print();

//        System.out.println(l.palindrome());
//        l.length();
//        System.out.println(l.linear(20));
//        l.del_beg();
//        l.del_end();


    }
}
