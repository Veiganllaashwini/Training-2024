import java.util.*;
public class coprime {
    public static void main(String[] args) {
        int n1=5;
        int n2=3;
        int i=2;
      while(i<=n1 && i<=n2){
          if(n1%i==0 && n2%i==0)
              System.out.println("noo");
          i++;
      }
        System.out.println("yes");




    }
    }

