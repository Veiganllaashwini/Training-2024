public class kth_largest_factor {
    public static void main(String[] args) {
        int n=7;
        int k=2;
        int ans=0;
        int min=Integer.MIN_VALUE;
        int greater=Integer.MAX_VALUE;
        for(int i=n;i>=1;i++){

            if(n%i==0){k--;
            }

            if(k==0){
                System.out.println(i);
            }
        }
//        int k=3;
//        for(int i=1;i<=n;i++){
//            if(n%i>0 && i<greater){
//                ans=i;
//                k--;
//            }
//        }

//        System.out.println(greater);
//        for(int j=2;j<=k;j++){
//        for(int i=1;i<=n;i++){
//            if(n%i==0){
//            if(i>min && i<greater){
//                min=i;
//            }
//            }
//
//        }
//        greater=min;
//        min=0;
//        }
//        System.out.println(greater);




    }
}
