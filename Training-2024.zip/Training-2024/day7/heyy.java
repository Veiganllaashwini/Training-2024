public class heyy {
    public static boolean isPrime(int n,int i,int cnt){
       if(i>n){

           if(cnt==2)
               return true;
           return false;
       }
        else{
            if(n%i==0){
                cnt++;
            }
            return isPrime(n,i+1,cnt);
        }
    }
    public static int count(int[] arr,int i,int cnt){

        if(i==arr.length){
            return cnt;}
        if(isPrime(arr[i],1,0))
            cnt++;
        i++;
        return count(arr,i,cnt);

        }



    public static void main(String[] args) {
        int n=5;
        int arr[]={1,2,3,4,5,6,7,13};

        System.out.println(isPrime(n,1,0));
        System.out.println(count(arr,0,0));
    }
}
