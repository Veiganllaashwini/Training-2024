public class valid_para {
    public static void main(String[] args) {

    }
}
